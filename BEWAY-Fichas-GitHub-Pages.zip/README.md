# BEWAY · Fichas de empresas

Diez fichas recuperadas de los originales más recientes y preparadas para GitHub Pages.
La publicación se gestiona desde el repositorio `jorgegrego19-collab/beway-fichas`.

## Publicación

1. Crear un repositorio de BEWAY y subir el contenido de esta carpeta a la rama `main`.
2. En Settings → Pages → Build and deployment, seleccionar GitHub Actions.
3. Ejecutar el workflow “Publicar fichas BEWAY”, o subir un nuevo cambio a `main`.
4. Usar la URL que indique el despliegue una vez completado.

GitHub Pages forma su dirección con el usuario u organización del repositorio. Para evitar
la palabra “chatgpt”, el propietario debe tener otro nombre o debe configurarse un dominio propio.
No se ha inventado ni configurado un dominio. Los nombres que siguen son rutas, no dominios registrados.

## Rutas

- `AurenxBeway/` — Auren
- `NetflixxBeway/` — Netflix
- `GooglexBeway/` — Google
- `SantanderxBeway/` — Santander
- `LorealxBeway/` — L’Oréal
- `IBMxBeway/` — IBM
- `McGrawHillxBeway/` — McGraw Hill
- `PwCxBeway/` — PwC
- `CentroGarriguesxBeway/` — Centro de Estudios Garrigues
- `InstitutoBMExBeway/` — Instituto BME

## Contenido

`public/` contiene la web estática, imágenes, fuentes y documentos originales de las fichas.
Se han adaptado a HTML los temas de Auren y Netflix. Se mantienen los colores, textos,
embajadores e interacciones de los originales. Los enlaces “Explora empresas” llevan al
directorio de este paquete. No requiere Shopify, Netlify ni ChatGPT para servir los archivos.

Los recursos repetidos de los HTML están guardados una sola vez en `public/assets/media`.
Las rutas relativas funcionan en dominios propios y en las rutas de proyecto de GitHub Pages.
Los formularios y simuladores conservan el comportamiento de demostración de las fichas originales;
esta migración no añade un backend ni cobros.

Para comprobarlo localmente: `python3 -m http.server 8000 --directory public`.
