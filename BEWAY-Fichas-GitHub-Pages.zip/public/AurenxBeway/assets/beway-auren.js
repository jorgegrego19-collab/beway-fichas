/* BEWAY Auren: isolated entry point for Shopify and the theme editor. */
(function(){
  'use strict';
  function initialize(context){
    const roots=context.matches&&context.matches('[data-beway-auren]')?[context]:Array.from(context.querySelectorAll('[data-beway-auren]'));
    roots.forEach(function(root){
      if(root.__bewayAurenInitialized)return;
      const mapElement=root.querySelector('[data-auren-assets]');
      if(!mapElement)return;
      const assets=JSON.parse(mapElement.textContent);
      const assetUrl=path=>assets[path]||path;
      root.__bewayAurenInitialized=true;
      const controller=new AbortController();
      const trackedWindow={addEventListener(type,handler,options){window.addEventListener(type,handler,Object.assign({},options,{signal:controller.signal}));}};
'use strict';

const MODULES = [
  {title:'Qué hace realmente un auditor',minutes:45,resources:10,assessment:5,description:'Comprende para qué sirve una auditoría, quién utiliza sus resultados y qué significan independencia, ética y escepticismo profesional.',lessons:['Qué aporta una auditoría a una empresa','Quién utiliza la información financiera','Independencia, ética y criterio profesional','El primer encargo: preguntas antes de empezar'],resource:'Glosario breve y mapa del recorrido de una auditoría.'},
  {title:'Entender una empresa a través de sus cuentas',minutes:50,resources:10,assessment:0,description:'Lee las ideas principales de un balance y una cuenta de resultados, y distingue beneficios, cobros y liquidez.',lessons:['Conocer el negocio antes de mirar los números','Qué nos dice un balance','Ventas, gastos y resultados','La empresa vende más: ¿por qué le falta liquidez?'],resource:'Cuentas simplificadas y lectura comentada del caso.'},
  {title:'Identificar dónde puede estar el problema',minutes:50,resources:5,assessment:5,description:'Conoce el riesgo de auditoría y la importancia relativa. Aprende a reconocer qué cuestiones pueden afectar a quienes utilizan las cuentas.',lessons:['De una señal a una pregunta de auditoría','Qué significa un riesgo de incorrección','Importancia relativa: qué puede cambiar una decisión','Priorizar la revisión de la empresa del curso'],resource:'Mapa inicial de riesgos y preguntas que deben comprobarse.'},
  {title:'Cómo funcionan los controles internos',minutes:50,resources:10,assessment:0,description:'Reconoce controles en compras, ventas, cobros y pagos, y comprende por qué importa quién autoriza y quién ejecuta.',lessons:['El recorrido de una compra y de un pago','Autorizaciones y separación de funciones','Qué puede fallar en un proceso','Revisión comentada de un control'],resource:'Matriz de riesgos y controles con un ejemplo resuelto.'},
  {title:'Qué cuenta como evidencia',minutes:55,resources:5,assessment:0,description:'Diferencia una explicación de una prueba y conoce distintas formas de obtener evidencia, atendiendo a su calidad y sus limitaciones.',lessons:['Qué necesitamos para sostener una conclusión','Documentos, confirmaciones y recuentos','Contrastar fuentes y resolver diferencias','Una operación, distintas evidencias'],resource:'Comparativa de evidencias y sus limitaciones.'},
  {title:'Revisar ventas, cobros e inventario',minutes:55,resources:5,assessment:0,description:'Observa pruebas sencillas sobre operaciones y saldos y aprende cómo se documenta lo revisado.',lessons:['De una venta al documento que la respalda','Cómo revisar un cobro','Contrastar inventario registrado y recuento','Documentar una prueba y lo que queda pendiente'],resource:'Ejemplo de papel de trabajo explicado.'},
  {title:'Datos, anomalías y herramientas digitales',minutes:50,resources:10,assessment:0,description:'Utiliza datos para encontrar operaciones que necesitan revisión y distingue una anomalía de una conclusión demostrada.',lessons:['Preparar y comprobar una tabla de operaciones','Duplicados, diferencias y fechas atípicas en Excel','Qué preguntas plantean las anomalías','Apoyo de la IA y revisión del profesional'],resource:'Hoja de cálculo del caso y demostración resuelta.'},
  {title:'Del hallazgo a la conclusión',minutes:35,resources:5,assessment:20,description:'Aprende a documentar lo observado y comprende cómo se reúnen los resultados y se expresa una opinión de auditoría.',lessons:['Hechos, evidencias y cuestiones pendientes','Cómo leer un informe de auditoría','El cierre del caso y la evaluación final'],resource:'Informe comentado y evaluación individual de quince preguntas.'}
];

const SOURCES = [
  ['Conoce Auren','https://auren.com/es/conoce-auren/','Presentación oficial de la firma'],
  ['Auditoría','https://auren.com/es/servicios/auditoria/','Servicios y enfoque de trabajo'],
  ['Propósito, visión y valores','https://auren.com/es/conoce-auren/proposito-vision-y-valores/','Cultura y valores'],
  ['Nuestro enfoque global','https://auren.com/es/conoce-auren/nuestro-enfoque-global/','Perspectiva internacional'],
  ['Responsabilidad corporativa','https://auren.com/es/conoce-auren/responsabilidad-corporativa/','Compromiso de la firma'],
  ['Informe de transparencia 2025','https://auren.com/es/wp-content/uploads/2025/01/Informe-Transparencia-2025.pdf','Metodología y formación de auditores'],
  ['Servicios de Auren','https://auren.com/es/servicios/','Auditoría, Legal, Consultoría y Corporate'],
  ['Empleo en Auren','https://empleo.auren.es/','Página oficial de oportunidades profesionales'],
  ['Comunidad de Líderes Hispanoamericanos','https://clhglobal.org/','Procedencia de los perfiles y fotografías de CLH']
];

const dialog=root.querySelector('#detail-dialog');
const dialogBody=root.querySelector('#dialog-body');
let previousFocus=null;
const external=(label,url,cls='btn outline')=>`<a class="${cls}" href="${url}" target="_blank" rel="noopener">${label} <span aria-hidden="true">↗</span></a>`;
function show(kicker,html){
  if(!dialog.open)previousFocus=document.activeElement;
  root.querySelector('#dialog-kicker').textContent=kicker;
  dialogBody.innerHTML=html;
  const heading=dialogBody.querySelector('h2');
  if(heading){heading.id='dialog-title';dialog.setAttribute('aria-labelledby','dialog-title');}
  if(!dialog.open)dialog.showModal();
  document.body.classList.add('beway-auren-modal-open');
  dialog.scrollTop=0;
}
function closeDialog(){dialog.close();document.body.classList.remove('beway-auren-modal-open');if(previousFocus?.isConnected)previousFocus.focus();}
root.querySelector('[data-close]').addEventListener('click',closeDialog);
dialog.addEventListener('cancel',e=>{e.preventDefault();closeDialog();});
dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeDialog();});

function moduleHTML(m,i){
  return `<details class="module"><summary><span class="module-number">${String(i+1).padStart(2,'0')}</span><div class="module-summary-text"><h4>${m.title}</h4><small>60 min en total · ${m.minutes} min de vídeo</small></div></summary><div class="module-content"><p>${m.description}</p><ul class="lesson-list">${m.lessons.map(t=>`<li><span>${t}</span><span>Vídeo breve</span></li>`).join('')}</ul><span class="module-resource">Material de apoyo: ${m.resource}</span><div class="module-timing">${m.minutes} min de vídeo · ${m.resources} min de recursos${m.assessment?' · '+m.assessment+' min de comprobación o evaluación':''}</div></div></details>`;
}
function openCourse(){
  show('AUREN EN BEWAY / PROGRAMA DEL CURSO',`<div class="dialog-inner"><p class="eyebrow">CURSO DE AUDITORÍA</p><h2>Comprende cómo<br>se revisa una empresa.</h2><p class="dialog-lead">Sigue el trabajo de un auditor, desde las primeras preguntas hasta las conclusiones del informe. Un recorrido introductorio centrado en auditoría financiera.</p><div class="course-modal-intro"><span>8 horas en total</span><span>100 % asíncrono</span><span>Dos jornadas de 4 horas</span><span>Nivel inicial</span></div><div class="time-breakdown"><div><strong>6 h 30 min</strong><span>vídeos grabados</span></div><div><strong>1 hora</strong><span>materiales de apoyo</span></div><div><strong>30 min</strong><span>comprobaciones y evaluación</span></div></div><div class="detail-block"><h3>Un caso que avanza contigo</h3><p>Una empresa ficticia vende material deportivo por internet y en tiendas. Sus ventas crecen, pero aparecen dudas sobre cobros, existencias y pagos. En vídeos de diez a quince minutos, los profesionales explicarían qué revisan, qué evidencias buscan y cómo justifican sus conclusiones.</p><p>Puedes pausar, retomar y volver a ver las explicaciones. Las dos jornadas son una forma de organizar el contenido; tú decides cuándo completarlas.</p></div><div class="journey-head"><span>PRIMERA JORNADA · CUATRO HORAS</span><h3>Comprender y preparar.</h3></div>${MODULES.slice(0,4).map((m,i)=>moduleHTML(m,i)).join('')}<div class="journey-head"><span>SEGUNDA JORNADA · CUATRO HORAS</span><h3>Revisar y explicar.</h3></div>${MODULES.slice(4).map((m,i)=>moduleHTML(m,i+4)).join('')}<div class="certificate-box"><span aria-hidden="true">✓</span><div><h3>Certificación oficial de Auren</h3><p>El planteamiento contempla un certificado de aprovechamiento emitido por Auren. Se propone completar los ocho módulos y superar una evaluación de quince preguntas con un mínimo del 80 % de aciertos. Auren validaría el programa y los requisitos de certificación.</p></div></div><div class="detail-block"><h3>Materiales para conservar</h3><p>Glosario, matriz de riesgos y controles, hoja de cálculo del caso y ejemplo de informe comentado. Los challenges y miniproyectos son actividades adicionales y opcionales.</p></div><div class="dialog-actions"><a class="btn primary" href="${assetUrl("assets/Programa_Curso_Auditoria_Auren.txt")}" download>Descargar programa <span aria-hidden="true">↓</span></a></div><p class="demo-context">Prototipo del curso para presentar a Auren. Las grabaciones y la inscripción todavía no están disponibles en esta demostración.</p></div>`);
}

function openInfo(id){
  const info={
    cultura:{title:'Un trabajo que se hace con personas.',lead:'Auren presenta una cultura humanista y un enfoque multidisciplinar para acompañar a empresas y organizaciones.',body:'Su página de empleo permite conocer su propósito, valores y oportunidades. Descubre las áreas y los perfiles que forman parte de la firma.',links:[['Cultura y valores','https://auren.com/es/conoce-auren/proposito-vision-y-valores/'],['Trabajar en Auren','https://empleo.auren.es/']]},
    auditoria:{title:'Una conclusión necesita evidencias.',lead:'La auditoría de cuentas conecta el conocimiento del negocio, la evaluación de riesgos y el control interno con la revisión de la información financiera.',body:'Auren publica servicios de auditoría de cuentas individuales y consolidadas, auditoría del sector público, due diligence y otros trabajos de assurance. El curso propuesto se centra en comprender el recorrido de una auditoría financiera.',links:[['Servicios de auditoría','https://auren.com/es/servicios/auditoria/'],['Informe de transparencia','https://auren.com/es/wp-content/uploads/2025/01/Informe-Transparencia-2025.pdf']]},
    global:{title:'Una perspectiva internacional.',lead:'Auren combina su trabajo con empresas y organizaciones con un enfoque global de los servicios profesionales.',body:'Explora su presencia internacional y cómo organiza la colaboración entre equipos. Las páginas oficiales permiten consultar el alcance y los servicios disponibles en cada país.',links:[['Enfoque global','https://auren.com/es/conoce-auren/nuestro-enfoque-global/'],['Conoce la firma','https://auren.com/es/conoce-auren/']]}
  }[id];
  if(!info)return;
  show('AUREN / CONOCE LA FIRMA',`<div class="dialog-inner"><h2>${info.title}</h2><p class="dialog-lead">${info.lead}</p><div class="detail-block"><p>${info.body}</p></div><div class="product-detail-links">${info.links.map(([t,u])=>external(t,u)).join('')}</div></div>`);
}
function openSources(){
  show('AUREN EN BEWAY / FUENTES OFICIALES',`<div class="dialog-inner"><p class="eyebrow">INFORMACIÓN CONTRASTADA</p><h2>Consulta las<br>fuentes originales.</h2><p class="dialog-lead">Fuentes públicas de la presentación y los servicios de Auren. El curso, los challenges y los miniproyectos son propuestas preparadas para este proyecto. Revisión: 20 de octubre de 2026.</p><ul class="sources-list">${SOURCES.map(([t,u,n],i)=>`<li><span>${String(i+1).padStart(2,'0')}</span><div><a href="${u}" target="_blank" rel="noopener">${t} ↗</a><small>${n}</small></div></li>`).join('')}</ul><p class="sources-note">Los perfiles de CLH representan el programa de embajadores BEWAY en esta demo. El programa de ocho horas no se atribuye a una oferta ya publicada por Auren.</p></div>`);
}

root.addEventListener('click',event=>{const button=event.target.closest('button');if(!button)return;if(button.hasAttribute('data-course'))openCourse();else if(button.dataset.info)openInfo(button.dataset.info);else if(button.hasAttribute('data-sources'))openSources();});
const navLinks=[...root.querySelectorAll('.section-nav a')];
const sections=navLinks.map(a=>root.querySelector(a.getAttribute('href')));
let ticking=false;
function updateNav(){let active=0;sections.forEach((section,i)=>{if(section.getBoundingClientRect().top<=165)active=i;});navLinks.forEach((a,i)=>{a.classList.toggle('active',i===active);if(i===active)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});ticking=false;}
trackedWindow.addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(updateNav);}},{passive:true});
updateNav();

'use strict';

const CHALLENGES = [
  {
    "id": "campus-conoce",
    "number": "01",
    "area": "COMUNICACIÓN · MARCA",
    "art": "AUREN EN<br>TU CAMPUS.",
    "title": "Que tu campus conozca Auren.",
    "short": "Diseña una campaña que explique qué hace Auren y por qué la auditoría puede interesar a otros estudiantes.",
    "mission": "Crea una campaña universitaria que acerque la actividad de Auren a personas de tu generación, con una situación de negocio fácil de reconocer.",
    "deadline": "72 horas de convocatoria",
    "purpose": "Dar a conocer la firma mediante mensajes y formatos creados desde la perspectiva universitaria.",
    "tasks": [
      "Elige un público de tu campus y una situación de negocio que le resulte cercana.",
      "Investiga la actividad de Auren en sus fuentes oficiales y decide qué quieres explicar.",
      "Desarrolla un vídeo vertical y dos piezas complementarias con un mensaje coherente.",
      "Explica por qué canales se descubriría la campaña y cómo conduciría a la ficha de Auren."
    ],
    "deliverables": [
      "Vídeo vertical de 30 a 45 segundos",
      "Dos piezas complementarias de comunicación",
      "Tres diapositivas: público, canales y recorrido hacia Auren"
    ],
    "criteria": "Claridad del mensaje, rigor sobre la actividad de Auren, creatividad y viabilidad.",
    "videoGuide": "Un vídeo vertical de 30 a 45 segundos, acompañado de las piezas y la explicación de la campaña."
  },
  {
    "id": "confianza-cuentas",
    "number": "02",
    "area": "AUDITORÍA · EXPERIENCIA DIGITAL",
    "art": "¿TE FÍAS DE<br>ESTAS CUENTAS?",
    "title": "¿Te fiarías de estas cuentas?",
    "short": "Diseña una experiencia de cinco minutos que permita descubrir cómo piensa un auditor.",
    "mission": "Una empresa vende cada vez más y declara beneficios, pero tiene dificultades para pagar a sus proveedores. Diseña una experiencia interactiva para investigar qué información hace falta.",
    "deadline": "Una semana de convocatoria",
    "purpose": "Proponer una experiencia educativa que Auren pueda utilizar para acercar la auditoría y despertar interés por el curso.",
    "tasks": [
      "Define el caso ficticio y qué datos se muestran al inicio.",
      "Prepara cinco pantallas con decisiones sobre documentos, preguntas o evidencias.",
      "Explica qué aprendería el usuario con cada elección y qué debe comprobar antes de concluir.",
      "Muestra cómo termina la experiencia y cómo invita a conocer Auren."
    ],
    "deliverables": [
      "Prototipo o guion de cinco pantallas",
      "Preguntas, opciones de respuesta y explicaciones",
      "Vídeo de presentación de hasta dos minutos"
    ],
    "criteria": "Comprensión de la auditoría, claridad de las decisiones, utilidad educativa y facilidad de participación.",
    "videoGuide": "Hasta dos minutos para recorrer el prototipo. Puedes utilizar bocetos o una herramienta de diseño; no es necesario programar."
  },
  {
    "id": "auditor-dia",
    "number": "03",
    "area": "EXPERIENCIAS · COMUNIDAD",
    "art": "AUDITOR<br>POR UN DÍA.",
    "title": "Auditor por un día en tu universidad.",
    "short": "Propón una actividad de campus que acerque Auren a estudiantes de distintas carreras.",
    "mission": "Diseña una actividad de 45 minutos que permita conocer Auren y participar en un pequeño caso de auditoría, con el apoyo de embajadores de CLH.",
    "deadline": "Una semana de convocatoria",
    "purpose": "Crear un formato de activación universitaria que pueda adaptarse a distintos campus.",
    "tasks": [
      "Define a quién convocarías y qué situación de empresa abriría la actividad.",
      "Organiza una agenda de 45 minutos con decisiones que pueda tomar el público.",
      "Explica qué harían los embajadores y qué intervención profesional sería necesaria.",
      "Prepara la convocatoria, los recursos y un presupuesto orientativo."
    ],
    "deliverables": [
      "Agenda de la actividad y descripción de la dinámica",
      "Una pieza de convocatoria",
      "Recursos, presupuesto e indicadores de participación"
    ],
    "criteria": "Conexión con los estudiantes, rigor del caso, viabilidad y capacidad de dar a conocer Auren.",
    "videoGuide": "Puedes acompañar tu propuesta con un vídeo de hasta dos minutos explicando cómo funcionaría la actividad."
  }
];

const PROJECTS = [
  {
    "id": "mapa-riesgos",
    "symbol": "↗",
    "label": "NEGOCIO · CONTROL INTERNO",
    "title": "El mapa de riesgos de un negocio.",
    "short": "Revisa una tienda online e identifica qué puede fallar y cómo podría controlarse.",
    "duration": "45–60 min",
    "level": "Inicial",
    "skills": [
      "Riesgos",
      "Control interno",
      "Análisis"
    ],
    "intro": "Identifica cinco riesgos y propón un control concreto para cada uno.",
    "caseText": "Caso ficticio: una tienda de material deportivo vende por internet y en un local. Una sola persona puede crear proveedores y autorizar pagos. Las devoluciones se registran al final de la semana, el inventario se cuenta una vez al año y las conciliaciones de cobros llevan dos meses de retraso. El negocio crece y quiere entender sus puntos débiles.",
    "data": [
      [
        "Negocio",
        "Material deportivo"
      ],
      [
        "Canales",
        "Online y tienda"
      ],
      [
        "Tu objetivo",
        "5 riesgos"
      ],
      [
        "Entrega",
        "Una página"
      ]
    ],
    "steps": [
      "Identifica cinco riesgos de los procesos de ventas, cobros, devoluciones, existencias o pagos.",
      "Relaciona cada riesgo con una posible consecuencia para la información o el negocio.",
      "Propón un control y explica quién debería realizarlo y cómo dejaría evidencia."
    ],
    "fields": [
      "Los cinco riesgos y sus posibles consecuencias",
      "El control que propones para cada riesgo y quién lo realizaría",
      "Qué revisarías primero y qué información pedirías"
    ],
    "deliverable": "Una página con riesgo, posible consecuencia y control propuesto."
  },
  {
    "id": "anomalias-datos",
    "symbol": "≠",
    "label": "DATOS · EXCEL",
    "title": "Encuentra qué necesita revisión.",
    "short": "Analiza un registro de operaciones y señala las diferencias que merecen una explicación.",
    "duration": "60–90 min",
    "level": "Inicial",
    "skills": [
      "Excel",
      "Evidencias",
      "Criterio"
    ],
    "intro": "Descarga los datos y prepara tres observaciones justificadas.",
    "caseText": "Caso ficticio: recibes un registro de 30 operaciones de compras y pagos. Busca referencias repetidas, diferencias de importes y fechas que necesiten revisión. El registro contiene información incompleta y no permite concluir por sí solo que exista un pago incorrecto o un fraude. Explica siempre qué documento o comprobación te falta.",
    "data": [
      [
        "Archivo",
        "CSV compatible con Excel"
      ],
      [
        "Registros",
        "30 operaciones"
      ],
      [
        "Tu objetivo",
        "3 observaciones"
      ],
      [
        "Origen",
        "Datos ficticios"
      ]
    ],
    "asset": "assets/Operaciones_Practica_Auren.csv",
    "assetLabel": "Descargar las 30 operaciones · CSV",
    "steps": [
      "Abre el archivo en Excel y revisa referencias, importes y fechas.",
      "Selecciona al menos tres cuestiones y explica qué dato te ha llamado la atención.",
      "Indica qué información solicitarías para comprobar cada observación."
    ],
    "fields": [
      "Operaciones señaladas y diferencias encontradas",
      "Por qué merecen revisión y qué explicación alternativa podría existir",
      "Documentos o comprobaciones que solicitarías"
    ],
    "deliverable": "El Excel marcado y una explicación breve de tres observaciones. Aquí puedes preparar y descargar el texto que acompañará al archivo."
  },
  {
    "id": "primer-hallazgo",
    "symbol": "✓",
    "label": "EVIDENCIAS · COMUNICACIÓN",
    "title": "Tu primer hallazgo.",
    "short": "Explica una observación con hechos, evidencias y preguntas que todavía quedan abiertas.",
    "duration": "45–60 min",
    "level": "Inicial",
    "skills": [
      "Documentación",
      "Comunicación",
      "Juicio profesional"
    ],
    "intro": "Prepara una observación breve que otra persona pueda entender y comprobar.",
    "caseText": "Caso ficticio: un pedido aprobado y una factura del proveedor son de 12.000 €. El extracto bancario muestra dos cargos de 12.000 € con la misma referencia, en días consecutivos. El registro contable recoge un único pago y todavía no has obtenido respuesta del proveedor. Debes describir la diferencia y decidir qué revisar antes de concluir.",
    "data": [
      [
        "Pedido y factura",
        "12.000 €"
      ],
      [
        "Extracto bancario",
        "2 cargos de 12.000 €"
      ],
      [
        "Registro contable",
        "1 pago"
      ],
      [
        "Proveedor",
        "Respuesta pendiente"
      ]
    ],
    "steps": [
      "Separa los hechos documentados de las explicaciones que todavía son hipótesis.",
      "Explica por qué importa la diferencia y qué información falta.",
      "Redacta una observación y prepara cómo la contarías en un minuto."
    ],
    "fields": [
      "Qué he observado y qué evidencias lo respaldan",
      "Por qué importa y qué no puedo concluir todavía",
      "Qué comprobaría después y cómo lo explicaría al equipo"
    ],
    "deliverable": "Una página y, si quieres presentar el trabajo completo, un vídeo de un minuto con tu explicación."
  }
];

const COMMUNITY_PEOPLE = [
  {
    "id": "martina-leich",
    "name": "Martina Leicht",
    "university": "Universidad de Montevideo",
    "country": "Uruguay",
    "area": "Comunicación estratégica/Marketing",
    "image": "assets/ambassadors/martina-leich.webp",
    "linkedIn": "https://www.linkedin.com/in/martina-leicht-05b44b340/"
  },
  {
    "id": "emily-torres-pineda",
    "name": "Emily Torres Pineda",
    "university": "Universidad del Rosario",
    "country": "Colombia",
    "area": "Derecho",
    "image": "assets/ambassadors/emily-torres-pineda.webp",
    "linkedIn": "https://www.linkedin.com/in/emily-torres-pineda/"
  },
  {
    "id": "michelle-rogel",
    "name": "Michelle Rogel",
    "university": "Universidad Anáhuac Mayab",
    "country": "México",
    "area": "Ingeniería Mecatrónica",
    "image": "assets/ambassadors/michelle-rogel.webp",
    "linkedIn": "https://www.linkedin.com/in/michelle-rogel-garc%C3%ADa-a37820219/"
  },
  {
    "id": "andrea-venegas",
    "name": "Andrea Venegas",
    "university": "Universidad de Granada",
    "country": "España",
    "area": "Criminología y Seguridad",
    "image": "assets/ambassadors/andrea-venegas.jpg",
    "linkedIn": "https://www.linkedin.com/in/andrea-venegas-de-la-rosa-a34162365"
  },
  {
    "id": "camila-calvo",
    "name": "Camila Calvo",
    "university": "ADEN",
    "country": "Panamá",
    "area": "Marketing",
    "image": "assets/ambassadors/camila-calvo.png",
    "linkedIn": "https://www.linkedin.com/in/camila-calvo-de-la-guardia/"
  }
];
PROJECTS.forEach(p=>{if(p.asset)p.asset=assetUrl(p.asset);});
COMMUNITY_PEOPLE.forEach(p=>{p.image=assetUrl(p.image);});
const escapeText=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const bullets=items=>'<ul>'+items.map(item=>`<li>${item}</li>`).join('')+'</ul>';

root.querySelector('#challenges-grid').innerHTML=CHALLENGES.map(c=>`<article class="challenge-card"><div class="challenge-art"><span class="art-tag">CHALLENGE ${c.number}</span><div class="challenge-type" aria-hidden="true">${c.art}</div><span class="card-num">${c.number}</span></div><div class="challenge-info"><p class="eyebrow">${c.area}</p><h3>${c.title}</h3><p>${c.short}</p><button data-challenge="${c.id}">Explorar Challenge <span aria-hidden="true">↗</span></button></div></article>`).join('');

function openChallenge(id){
  const c=CHALLENGES.find(v=>v.id===id);if(!c)return;
  show('AUREN EN BEWAY / CHALLENGE '+c.number,`<div class="dialog-inner"><p class="eyebrow">${c.area}</p><h2>${c.title}</h2><p class="dialog-lead">${c.mission}</p><div class="chips"><span>Individual o en equipo</span><span>${c.deadline}</span><span>Plazo propuesto</span></div><div class="challenge-summary"><div class="activity-block"><h3>Tu misión, paso a paso</h3><ol>${c.tasks.map(t=>`<li>${t}</li>`).join('')}</ol><h3>Qué se valoraría</h3><p>${c.criteria}</p><h3>Tu aportación a Auren</h3><p>${c.purpose}</p></div><aside class="activity-deliverable"><h3>Qué entregar</h3>${bullets(c.deliverables)}<h3>Cómo explicarlo</h3><p>${c.videoGuide}</p></aside></div><p class="no-open-convocation">Propuesta para esta demo. La convocatoria y la recepción de entregas todavía no están abiertas. Los materiales técnicos necesitarían revisión de Auren antes de su publicación.</p></div>`);
}

root.querySelector('#mini-projects-grid').innerHTML=PROJECTS.map(p=>`<article class="mini-project"><div class="project-symbol" aria-hidden="true">${p.symbol}</div><p class="project-label">${p.label}</p><h3>${p.title}</h3><p>${p.short}</p><div class="project-skills">${p.skills.map(s=>`<span>${s}</span>`).join('')}</div><div class="project-facts"><div><strong>${p.duration}</strong><small>orientativas</small></div><div><strong>${p.level}</strong><small>dificultad</small></div><div><strong>Individual</strong><small>caso guiado</small></div></div><button data-project="${p.id}">Comenzar miniproyecto <span aria-hidden="true">↗</span></button></article>`).join('');

function readProjectDraft(id){
  try{
    const data=JSON.parse(localStorage.getItem('beway-auren-draft-'+id)||'{}');
    if(!data||typeof data!=='object'||Array.isArray(data))return {};
    const result={};
    for(let i=0;i<3;i++)if(typeof data['answer'+i]==='string')result['answer'+i]=data['answer'+i].slice(0,5000);
    return result;
  }catch{return {};}
}
function openProject(id){
  const p=PROJECTS.find(v=>v.id===id);if(!p)return;
  const draft=readProjectDraft(id);
  const hasDraft=Object.values(draft).some(t=>t.trim());
  show('BEWAY / MINIPROYECTO DE PRÁCTICA',`<div class="dialog-inner"><p class="eyebrow">${p.label}</p><h2>${p.title}</h2><p class="dialog-lead">${p.intro}</p><div class="course-modal-intro"><span>${p.duration} orientativas</span><span>Dificultad ${p.level.toLowerCase()}</span><span>Trabajo individual</span></div><div class="project-case"><h3>El caso</h3><p>${p.caseText}</p><div class="case-data">${p.data.map(([label,value])=>`<div>${label}<strong>${value}</strong></div>`).join('')}</div></div>${p.asset?`<div class="project-download"><a class="btn outline" href="${p.asset}" download>${p.assetLabel} <span aria-hidden="true">↓</span></a></div>`:''}<div class="activity-block"><h3>Qué tienes que hacer</h3><ol>${p.steps.map(s=>`<li>${s}</li>`).join('')}</ol><h3>Tu trabajo final</h3><p>${p.deliverable}</p></div><form class="project-form" data-project-form="${p.id}"><h3>Prepara tu borrador</h3>${p.fields.map((label,i)=>`<div class="field"><label for="project-${p.id}-${i}">${i+1}. ${label}</label><textarea id="project-${p.id}-${i}" name="answer${i}" rows="4" maxlength="5000" placeholder="Escribe aquí tu respuesta...">${escapeText(draft['answer'+i]||'')}</textarea></div>`).join('')}<div class="dialog-actions"><button type="button" class="btn primary" data-save-project="${p.id}">Guardar borrador <span aria-hidden="true">✓</span></button><button type="button" class="btn outline" data-export-project="${p.id}">Descargar trabajo <span aria-hidden="true">↓</span></button></div><p class="project-save-status" role="status" aria-live="polite">${hasDraft?'Has recuperado el borrador guardado en este dispositivo.':''}</p><p class="project-storage-note">El borrador se guarda solo en este navegador. Guardar o descargar no envía tu trabajo a BEWAY ni a Auren.</p></form><p class="no-open-convocation">Caso de práctica para esta demo. La evaluación y la incorporación al portfolio se habilitarían en la convocatoria definitiva.</p></div>`);
}
function projectAnswers(form){
  const result={};for(let i=0;i<3;i++)result['answer'+i]=String(new FormData(form).get('answer'+i)||'').slice(0,5000);return result;
}
function saveProject(form,id){
  if(!form)return;
  const status=form.querySelector('.project-save-status');
  try{localStorage.setItem('beway-auren-draft-'+id,JSON.stringify(projectAnswers(form)));status.textContent='Borrador guardado en este dispositivo.';}
  catch{status.textContent='No se ha podido guardar en este navegador. Puedes descargar tu trabajo para conservarlo.';}
}
function exportProject(form,id){
  const p=PROJECTS.find(v=>v.id===id);if(!form||!p)return;
  const answers=projectAnswers(form);
  const text=['BEWAY · MINIPROYECTO DE PRÁCTICA',p.title,'','Caso ficticio. Trabajo sin evaluar.','',...p.fields.flatMap((label,i)=>[(i+1)+'. '+label,answers['answer'+i]||'(Sin respuesta)',''])].join('\n');
  const url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='BEWAY-miniproyecto-'+p.id+'.txt';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  form.querySelector('.project-save-status').textContent='Tu trabajo está preparado para descargar.';
}

root.querySelector('#ambassadors-grid').innerHTML=COMMUNITY_PEOPLE.map(p=>`<article class="ambassador"><div class="member-photo${p.id==='emily-torres-pineda'?' member-photo-zoom':''}"><img src="${p.image}" alt="${escapeText(p.name)}" width="78" height="78" loading="lazy"></div><span class="member-badge">CLH</span><h3>${escapeText(p.name)}</h3><p>${escapeText(p.university)}</p><span class="campus">${escapeText(p.country)} · Comunidad CLH</span><button class="text-button" data-person="${p.id}">Conocer perfil ↗</button></article>`).join('');
function openPerson(id){
  const p=COMMUNITY_PEOPLE.find(v=>v.id===id);if(!p)return;
  show('BEWAY / COMUNIDAD CLH',`<div class="dialog-inner"><div class="member-profile-top"><div class="member-photo${p.id==='emily-torres-pineda'?' member-photo-zoom':''}"><img src="${p.image}" alt="${escapeText(p.name)}" width="104" height="104"></div><div><h2>${escapeText(p.name)}</h2><p>${escapeText(p.university)} · ${escapeText(p.country)}</p><span class="member-badge">MIEMBRO DE CLH</span></div></div><div class="chips"><span>${escapeText(p.area)}</span><span>Comunidad universitaria</span></div><div class="detail-block"><h3>El papel de un embajador en BEWAY</h3><ul><li>Acercar el curso, los Challenges y los miniproyectos a su campus.</li><li>Ayudar a entender cómo participar y qué hay que preparar.</li><li>Canalizar las dudas y conectar a los estudiantes con la comunidad.</li></ul></div><div class="dialog-actions">${external('Ver perfil de LinkedIn',p.linkedIn,'btn primary')}${external('Conocer CLH','https://clhglobal.org/')}</div><p class="section-note">Perfil real de CLH utilizado para representar el programa de embajadores de BEWAY en esta demo.</p></div>`);
}

root.addEventListener('click',event=>{
  const button=event.target.closest('button');if(!button)return;
  if(button.dataset.challenge)openChallenge(button.dataset.challenge);
  else if(button.dataset.project)openProject(button.dataset.project);
  else if(button.dataset.person)openPerson(button.dataset.person);
  else if(button.dataset.saveProject)saveProject(button.closest('form'),button.dataset.saveProject);
  else if(button.dataset.exportProject)exportProject(button.closest('form'),button.dataset.exportProject);
});
root.addEventListener('submit',event=>{
  const form=event.target.closest('[data-project-form]');if(!form)return;
  event.preventDefault();saveProject(form,form.dataset.projectForm);
});

      root.__bewayAurenCleanup=function(){controller.abort();if(dialog.open)closeDialog();root.__bewayAurenInitialized=false;};
    });
  }
  if(window.__bewayAurenInitialize){window.__bewayAurenInitialize(document);return;}
  window.__bewayAurenInitialize=initialize;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){initialize(document);},{once:true});
  else initialize(document);
  document.addEventListener('shopify:section:load',function(event){initialize(event.target);});
  document.addEventListener('shopify:section:unload',function(event){
    const root=event.target.matches&&event.target.matches('[data-beway-auren]')?event.target:event.target.querySelector('[data-beway-auren]');
    if(root&&root.__bewayAurenCleanup)root.__bewayAurenCleanup();
  });
})();
