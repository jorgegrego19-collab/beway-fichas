'use strict';
(function(){
  const D=window.BEWAY_NETFLIX;
  const dialog=document.querySelector('#detail-dialog');
  const body=document.querySelector('#dialog-body');
  let previousFocus=null;
  const e=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const list=items=>'<ul>'+items.map(v=>'<li>'+e(v)+'</li>').join('')+'</ul>';
  const external=(label,url,cls='btn outline')=>'<a class="'+cls+'" href="'+e(url)+'" target="_blank" rel="noopener">'+e(label)+' <span aria-hidden="true">↗</span></a>';
  function show(kicker,html){
    window.dispatchEvent(new Event('beway:before-dialog-change'));
    if(!dialog.open)previousFocus=document.activeElement;
    document.querySelector('#dialog-kicker').textContent=kicker;
    body.innerHTML=html;
    const heading=body.querySelector('h2');
    if(heading){heading.id='dialog-title';dialog.setAttribute('aria-labelledby','dialog-title');}
    if(!dialog.open)dialog.showModal();
    document.body.classList.add('modal-open');dialog.scrollTop=0;
  }
  function close(){
    window.dispatchEvent(new Event('beway:before-dialog-change'));
    dialog.close();document.body.classList.remove('modal-open');
    if(previousFocus?.isConnected)previousFocus.focus();
  }
  document.querySelector('[data-close]').addEventListener('click',close);
  dialog.addEventListener('cancel',event=>{event.preventDefault();close();});
  dialog.addEventListener('click',event=>{
    if(event.target!==dialog)return;
    const r=dialog.getBoundingClientRect();
    if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)close();
  });
  function download(name,text,type='text/plain;charset=utf-8'){
    const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');
    a.href=url;a.download=name;document.body.append(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1500);
  }
  function readStorage(key,fallback){
    try{const raw=localStorage.getItem(key);return raw?JSON.parse(raw):fallback;}catch{return fallback;}
  }
  function writeStorage(key,data){
    try{localStorage.setItem(key,JSON.stringify(data));return true;}catch{return false;}
  }
  function cover(course){
    if(course.id==='guion')return '<div class="course-paper" aria-hidden="true"><b>EPISODIO PILOTO</b>INT. ESTACIÓN · NOCHE<i></i><i></i><i></i>ELENA<i></i><i></i><small>Una historia empieza con una decisión.</small></div>';
    if(course.id==='presupuestos')return '<div class="budget-preview" aria-hidden="true"><div><span>Desarrollo</span><span>01</span></div><div><span>Rodaje</span><span>02</span></div><div><span>Posproducción</span><span>03</span></div><div><span>Contingencia</span><span>04</span></div></div>';
    return '<div class="campaign-preview" aria-hidden="true"><b>PLAN DE LANZAMIENTO</b><div class="campaign-bars"><i></i><i></i><i></i><i></i><i></i></div></div>';
  }
  const coverTitles={guion:'Cómo se construye una historia',presupuestos:'Qué hace posible una producción',marketing:'Cómo una historia encuentra a su público'};
  document.querySelector('#courses-grid').innerHTML=D.courses.map((c,i)=>
    '<article class="course-card"><div class="course-art '+e(c.cover)+'"><span class="course-art-label">NETFLIX EN BEWAY · PROGRAMA PROPUESTO</span>'+cover(c)+'<strong class="course-cover-title">'+e(coverTitles[c.id])+'</strong><span class="poster-number" aria-hidden="true">0'+(i+1)+'</span></div><div class="course-card-content"><p class="eyebrow">'+e(c.tag)+'</p><h3>'+e(c.title)+'.</h3><p>'+e(c.short)+'</p><div class="course-card-facts"><span><b>8</b> horas</span><span><b>8</b> módulos</span><span>A tu ritmo</span></div><button data-course="'+e(c.id)+'">Ver programa completo <span aria-hidden="true">↗</span></button></div></article>'
  ).join('');
  function courseText(c){
    const lines=['NETFLIX EN BEWAY · PROPUESTA DE CURSO',c.title,'8 horas · Dos jornadas orientativas · Formato asíncrono','6 h 30 min de vídeos · 1 h de recursos · 30 min de evaluación','',c.short,''];
    c.modules.forEach((m,i)=>{if(i===0||i===4)lines.push('JORNADA '+(i===0?'1':'2')+' · 4 HORAS','');lines.push((i+1)+'. '+m.title,'Vídeos previstos: '+m.videoMinutes+' minutos');m.lessons.forEach(l=>lines.push('- '+l));lines.push('Recurso: '+m.resource,'');});
    lines.push('Propuesta de programa, contenidos y certificación oficial a validar por Netflix. Los vídeos y la matrícula no están disponibles en esta demo.');
    return lines.join('\n');
  }
  function openCourse(id){
    const c=D.courses.find(c=>c.id===id);if(!c)return;
    const units=c.modules.map((m,i)=>
      (i===0||i===4?'<div class="journey-head"><span>JORNADA '+(i===0?'01':'02')+' · 4 HORAS</span><h3>'+(i===0?'Comprende las bases de la profesión.':'Sigue las decisiones de un caso completo.')+'</h3></div>':'')+
      '<details class="module"'+(i===0?' open':'')+'><summary><span class="module-number">'+String(i+1).padStart(2,'0')+'</span><div class="module-summary-text"><h4>'+e(m.title)+'</h4><small>1 hora total · Vídeos previstos: '+m.videoMinutes+' min</small></div></summary><div class="module-content"><ul class="lesson-list">'+m.lessons.map((l,j)=>'<li><span>'+e(l)+'</span><span>Vídeo '+(j+1)+'</span></li>').join('')+'</ul><span class="module-resource">Material de apoyo: '+e(m.resource)+'.</span><span class="module-resource">El tiempo restante del módulo se dedica a recursos y comprobaciones breves.</span></div></details>'
    ).join('');
    show('NETFLIX / CURSO PROPUESTO','<div class="dialog-inner"><span class="programme-tag">Propuesta de formación propia de Netflix</span><p class="eyebrow">'+e(c.tag)+'</p><h2>'+e(c.title)+'.</h2><p class="dialog-lead">'+e(c.short)+'</p><div class="course-modal-intro"><span>8 horas totales</span><span>8 módulos</span><span>100 % asíncrono</span><span>Dos jornadas orientativas</span></div><div class="time-breakdown"><div><strong>6 h 30 min</strong><span>Vídeos y ejemplos comentados</span></div><div><strong>1 hora</strong><span>Materiales de apoyo</span></div><div><strong>30 min</strong><span>Comprobaciones y evaluación</span></div></div><p class="course-outcome">'+e(c.outcome)+'</p><p class="course-audience">'+e(c.audience)+'</p>'+units+'<div class="certificate-box"><span aria-hidden="true">✓</span><div><h3>Certificación oficial de Netflix prevista en la propuesta.</h3><p>Netflix tendría que validar el programa, los contenidos y la evaluación y autorizar la emisión del certificado.</p></div></div><div class="course-modal-footer"><p>La demo muestra el temario. Los vídeos, los recursos docentes y la matrícula se desarrollarían con Netflix. Los ejercicios de desarrollo serían opcionales.</p><div class="dialog-actions"><button class="btn primary" data-course-export="'+e(c.id)+'">Descargar el temario <span aria-hidden="true">↓</span></button><button class="btn outline" data-close-modal>Volver a la ficha</button></div></div></div>');
  }
  const challengeArt={elegir:['Elegir qué ver puede ser más sencillo.','<div class="ux-screens" aria-hidden="true"><i></i><i></i><i></i></div>'],ads:['La publicidad también puede aportar valor.','<span class="ads-play" aria-hidden="true">▷</span>'],estreno:['Un estreno que se vive en tu campus.','<span class="premiere-shape" aria-hidden="true"></span>']};
  document.querySelector('#challenges-grid').innerHTML=D.challenges.map(c=>'<article class="challenge-card"><div class="challenge-art"><span class="art-tag">CHALLENGE '+e(c.number)+'</span>'+challengeArt[c.id][1]+'<div class="challenge-type" aria-hidden="true">'+e(challengeArt[c.id][0])+'</div><span class="card-num" aria-hidden="true">'+e(c.number)+'</span></div><div class="challenge-info"><p class="eyebrow">'+e(c.area)+'</p><h3>'+e(c.title)+'.</h3><p>'+e(c.short)+'</p><button data-challenge="'+e(c.id)+'">Explorar el challenge <span aria-hidden="true">↗</span></button></div></article>').join('');
  function challengeDraft(c){
    const raw=readStorage('beway-netflix-challenge-'+c.id,{});const data={};
    c.slides.forEach((_,i)=>{data['answer'+i]=typeof raw?.['answer'+i]==='string'?raw['answer'+i].slice(0,6000):'';});return data;
  }
  function openChallenge(id){
    const c=D.challenges.find(c=>c.id===id);if(!c)return;const draft=challengeDraft(c);
    show('BEWAY / CHALLENGE '+c.number,'<div class="dialog-inner"><p class="eyebrow">'+e(c.area)+'</p><h2>'+e(c.title)+'.</h2><p class="dialog-lead">'+e(c.mission)+'</p><div class="chips"><span>Una propuesta por participante</span><span>Distintas carreras</span><span>Propuesta conceptual</span></div><div class="challenge-summary"><div class="activity-block"><h3>Tu misión, paso a paso</h3><ol>'+c.tasks.map(t=>'<li>'+e(t)+'</li>').join('')+'</ol><h3>Qué se valoraría</h3><p>'+e(c.criteria)+'</p><h3>Cómo prepararlo</h3><p>'+e(c.extra)+'</p></div><aside class="activity-deliverable"><h3>Qué entregar</h3><p><strong>Un PDF de hasta cinco diapositivas</strong></p>'+list(c.slides)+'<h3>Un vídeo de dos a tres minutos</h3><p>Explica tu idea y las decisiones que has tomado. La duración máxima prevista es de tres minutos.</p></aside></div><form class="project-form" id="challenge-form" data-draft-id="'+e(c.id)+'"><h3>Prepara tu borrador</h3><p class="activity-lead">Puedes trabajar aquí y descargar el texto para preparar tus diapositivas.</p>'+c.slides.map((label,i)=>'<div class="field"><label for="challenge-answer-'+i+'">'+e(label)+'</label><textarea id="challenge-answer-'+i+'" name="answer'+i+'" maxlength="6000" rows="4">'+e(draft['answer'+i])+'</textarea></div>').join('')+'<div class="dialog-actions"><button type="button" class="btn primary" data-challenge-save="'+e(c.id)+'">Guardar borrador</button><button type="button" class="btn outline" data-challenge-export="'+e(c.id)+'">Descargar mi propuesta ↓</button></div><p class="project-save-status" id="challenge-status" role="status" aria-live="polite"></p><p class="project-storage-note">El borrador se guarda en este navegador. La descarga conserva una copia del texto; todavía no se envía a BEWAY ni a Netflix.</p></form><p class="no-open-convocation">La entrega, las fechas y el reconocimiento se concretarían con Netflix. En el itinerario propuesto, la acreditación exige completar el onboarding y superar un challenge con el nivel mínimo establecido.</p></div>');
  }
  function collectChallenge(id){
    const c=D.challenges.find(c=>c.id===id),form=document.querySelector('#challenge-form');if(!c||!form)return null;
    return Object.fromEntries(c.slides.map((_,i)=>['answer'+i,String(form.elements.namedItem('answer'+i)?.value||'').slice(0,6000)]));
  }
  function saveChallenge(id,quiet=false){
    const draft=collectChallenge(id);if(!draft)return false;const ok=writeStorage('beway-netflix-challenge-'+id,draft);
    const status=document.querySelector('#challenge-status');if(!quiet&&status)status.textContent=ok?'Borrador guardado en este navegador.':'No se ha podido guardar aquí. Descarga tu propuesta para conservarla.';return ok;
  }
  function exportChallenge(id){
    const c=D.challenges.find(c=>c.id===id),draft=collectChallenge(id);if(!c||!draft)return;
    saveChallenge(id,true);const lines=['BEWAY · NETFLIX',c.title,'BORRADOR DEL PARTICIPANTE',''];
    c.slides.forEach((label,i)=>lines.push(label.toUpperCase(),draft['answer'+i]||'[Pendiente de completar]',''));
    lines.push('Entrega prevista: PDF de hasta cinco diapositivas y vídeo de dos a tres minutos.');download('BEWAY-Netflix-Challenge-'+c.id+'.txt',lines.join('\n'));
    document.querySelector('#challenge-status').textContent='Se ha preparado la descarga de tu propuesta.';
  }
  window.addEventListener('beway:before-dialog-change',()=>{const form=document.querySelector('#challenge-form');if(form)saveChallenge(form.dataset.draftId,true);});
  const photo=p=>'<span class="member-photo'+(p.id==='camila-calvo'?' member-photo-zoom':'')+'"><img src="'+e(p.image)+'" alt="'+e(p.name)+'" width="78" height="78" loading="lazy"></span>';
  document.querySelector('#ambassadors-grid').innerHTML=D.people.map(p=>'<article class="ambassador">'+photo(p)+'<h3>'+e(p.name)+'</h3><p>'+e(p.university)+'</p><span class="campus">'+e(p.country)+' · '+e(p.area)+'</span><span class="member-badge">MIEMBRO DE CLH</span><button class="text-button" data-person="'+e(p.id)+'">Conocer su perfil ↗</button></article>').join('');
  function openPerson(id){
    const p=D.people.find(p=>p.id===id);if(!p)return;
    show('BEWAY / COMUNIDAD CLH','<div class="dialog-inner"><div class="member-profile-top">'+photo(p)+'<div><h2>'+e(p.name)+'</h2><p>'+e(p.university)+' · '+e(p.country)+'</p><span class="member-badge">MIEMBRO DE CLH</span></div></div><p class="dialog-lead">Un punto de encuentro entre estudiantes, comunidades y las actividades de BEWAY.</p><div class="info-panel"><h3>El papel de los embajadores</h3><p>Acercar los cursos y los challenges a su entorno universitario, orientar sobre las actividades y ayudar a los estudiantes a dar el primer paso.</p></div><p class="section-note">Perfil real de CLH mostrado como ejemplo del programa de embajadores de esta demo. No implica una vinculación profesional con Netflix.</p><div class="dialog-actions">'+external('Ver su LinkedIn',p.linkedIn)+external('Conocer CLH','https://clhglobal.org/')+'</div></div>');
  }
  function openSources(){
    const corporate=D.sources.filter(s=>s.group==='Netflix'||s.group==='Comunidad');const academic=D.sources.filter(s=>!corporate.includes(s));
    const render=sources=>'<ul class="sources-list">'+sources.map((s,i)=>'<li><span>'+String(i+1).padStart(2,'0')+'</span><div><a href="'+e(s.url)+'" target="_blank" rel="noopener">'+e(s.title)+' ↗</a><small>'+e(s.group)+'</small></div></li>').join('')+'</ul>';
    show('BEWAY / FUENTES Y REFERENCIAS','<div class="dialog-inner"><h2>Información oficial y base de la propuesta.</h2><p class="dialog-lead">Las referencias de Netflix sustentan la presentación de la compañía, el caso de mercados y el acceso a su tienda.</p>'+render(corporate)+'<details class="source-details"><summary>Referencias académicas de los programas</summary><p class="section-note">Grados, másteres y cursos consultados para preparar los temarios. Su inclusión como referencia no implica un acuerdo con estas instituciones.</p>'+render(academic)+'</details><p class="sources-note">Consulta realizada el 20 de octubre de 2026. Los cursos y la certificación son propuestas para validar con Netflix. Los datos del miniproyecto están identificados como ficticios.</p></div>');
  }
  document.addEventListener('click',event=>{
    const button=event.target.closest('[data-course],[data-challenge],[data-person],[data-sources],[data-course-export],[data-challenge-save],[data-challenge-export],[data-close-modal]');
    if(!button)return;
    if(button.hasAttribute('data-course'))openCourse(button.dataset.course);
    else if(button.hasAttribute('data-challenge'))openChallenge(button.dataset.challenge);
    else if(button.hasAttribute('data-person'))openPerson(button.dataset.person);
    else if(button.hasAttribute('data-sources'))openSources();
    else if(button.hasAttribute('data-course-export')){const c=D.courses.find(c=>c.id===button.dataset.courseExport);if(c)download('BEWAY-Netflix-Programa-'+c.id+'.txt',courseText(c));}
    else if(button.hasAttribute('data-challenge-save'))saveChallenge(button.dataset.challengeSave);
    else if(button.hasAttribute('data-challenge-export'))exportChallenge(button.dataset.challengeExport);
    else close();
  });
  document.addEventListener('submit',event=>{if(event.target.id==='challenge-form')event.preventDefault();});
  if('IntersectionObserver'in window){
    const navLinks=[...document.querySelectorAll('.section-nav a')];
    const observer=new IntersectionObserver(entries=>{
      entries.filter(entry=>entry.isIntersecting).sort((a,b)=>b.intersectionRatio-a.intersectionRatio).slice(0,1).forEach(entry=>navLinks.forEach(link=>{
        const active=link.getAttribute('href')==='#'+entry.target.id;link.classList.toggle('active',active);if(active)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');
      }));
    },{rootMargin:'-80px 0px -52% 0px',threshold:[0,.1,.4]});
    document.querySelectorAll('.page-content>section').forEach(section=>observer.observe(section));
  }
  window.BEWAY_UI=Object.freeze({show,close,escapeText:e,download,readStorage,writeStorage,external});
})();
