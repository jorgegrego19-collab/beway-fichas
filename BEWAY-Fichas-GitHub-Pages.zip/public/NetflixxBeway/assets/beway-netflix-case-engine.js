(function(root,factory){'use strict';if(typeof module==='object'&&module.exports)module.exports=factory();else root.NetflixCase=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const INVEST=new Set(['include','promote','localise']);
  function cleanDraft(raw,data){
    const source=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
    const state={version:1,activeCountry:data.countries.some(c=>c.id===source.activeCountry)?source.activeCountry:data.countries[0].id,decisions:{},answers:{strategy:'',evidence:'',risks:''}};
    const actions=new Set(data.actions.map(a=>a.id));
    for(const c of data.countries)for(const t of data.titles){
      const key=c.id+':'+t.id;const action=source.decisions?.[key];
      state.decisions[key]=t.rights.includes(c.id)&&actions.has(action)?action:'pending';
    }
    for(const key of Object.keys(state.answers))if(typeof source.answers?.[key]==='string')state.answers[key]=source.answers[key].slice(0,6000);
    return state;
  }
  function cost(title,country,action,data){
    if(!title||!country||!INVEST.has(action)||!title.rights.includes(country.id))return 0;
    const license=Math.round(title.license*country.factor);
    const sameLanguage=title.language===country.language;
    const languageCost=sameLanguage?0:(action==='localise'?data.dubbingCost:data.subtitleCost);
    return license+languageCost+(action==='promote'||action==='localise'?data.promotionCost:0);
  }
  function summary(country,state,data){
    let spent=0,selected=0,decided=0,available=0;
    for(const t of data.titles){
      if(!t.rights.includes(country.id))continue;
      available++;const action=state.decisions[country.id+':'+t.id]||'pending';
      if(action!=='pending')decided++;
      if(INVEST.has(action))selected++;
      spent+=cost(t,country,action,data);
    }
    return {spent,selected,decided,available,budget:country.budget,remaining:country.budget-spent,over:spent>country.budget};
  }
  function exportCSV(state,data){
    const rows=[['CASO FICTICIO BEWAY — decisiones del participante; datos y costes simulados.'],['Mercado','Título','Género','Derechos en el caso','Decisión','Coste en unidades']];
    for(const c of data.countries)for(const t of data.titles){
      const action=state.decisions[c.id+':'+t.id]||'pending';
      rows.push([c.name,t.title,t.genre,t.rights.includes(c.id)?'Disponibles':'No disponibles',t.rights.includes(c.id)?data.actions.find(a=>a.id===action)?.label||'Por decidir':'Sin derechos',cost(t,c,action,data)]);
    }
    return '\uFEFF'+rows.map(row=>row.map(value=>'"'+String(value).replace(/"/g,'""')+'"').join(';')).join('\r\n')+'\r\n';
  }
  function exportText(state,data){
    const lines=['BEWAY · NETFLIX','MINIPROYECTO: CATÁLOGO PARA SEIS MERCADOS','Caso ficticio. Datos, derechos y costes simulados.',''];
    for(const c of data.countries){const s=summary(c,state,data);lines.push(c.name.toUpperCase(),`Presupuesto: ${s.spent}/${s.budget} unidades · Títulos seleccionados: ${s.selected} · Decisiones: ${s.decided}/${s.available}`);
      for(const t of data.titles){const action=state.decisions[c.id+':'+t.id]||'pending';const label=t.rights.includes(c.id)?data.actions.find(a=>a.id===action)?.label||'Por decidir':'Sin derechos en el caso';lines.push(`- ${t.title}: ${label} (${cost(t,c,action,data)} unidades)`);}lines.push('');}
    for(const [key,label]of [['strategy','ESTRATEGIA Y PRIORIDADES'],['evidence','INVESTIGACIÓN Y FUENTES'],['risks','RIESGOS E HIPÓTESIS']])lines.push(label,state.answers[key]||'[Pendiente de completar]','');
    return lines.join('\n');
  }
  return Object.freeze({cleanDraft,cost,summary,exportCSV,exportText});
});
