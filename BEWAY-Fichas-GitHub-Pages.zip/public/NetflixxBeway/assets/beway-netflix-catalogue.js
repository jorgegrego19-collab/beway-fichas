'use strict';
(function(){
  const UI=window.BEWAY_UI,engine=window.NetflixCase,data=window.BEWAY_NETFLIX.case,e=UI.escapeText;
  const KEY='beway-netflix-catalogue-v1';
  let state=null,active=false;
  const country=()=>data.countries.find(c=>c.id===state.activeCountry);
  function answers(){
    if(!active)return;
    for(const key of ['strategy','evidence','risks']){
      const field=document.querySelector('#case-answer-'+key);
      if(field)state.answers[key]=field.value.slice(0,6000);
    }
  }
  function persist(visible=false){
    if(!active||!state)return false;answers();const ok=UI.writeStorage(KEY,state);
    const status=document.querySelector('#case-save-status');
    if(status&&visible)status.textContent=ok?'Borrador guardado en este navegador.':'No se ha podido guardar en este navegador. Descarga la propuesta para conservarla.';
    return ok;
  }
  function rules(){
    return '<div class="case-instructions"><p>Trabajas en un equipo que estudia un catálogo de doce títulos para seis países. Cada mercado dispone de <strong>100 unidades de presupuesto</strong>. Investiga las oportunidades y decide en qué historias invertir.</p><div class="case-rules"><div class="case-rule"><strong>Derechos por territorio</strong>Solo puedes incorporar títulos cuyos derechos estén disponibles en el mercado del caso.</div><div class="case-rule"><strong>Interés simulado de 0 a 100</strong>Es una señal ficticia para comparar propuestas. Debes contrastar tus hipótesis con investigación.</div><div class="case-rule"><strong>Adaptación lingüística</strong>Incorporar incluye 2 unidades de subtítulos si el idioma es distinto. El doblaje cuesta 8 unidades y sustituye a esos subtítulos.</div><div class="case-rule"><strong>Promoción del título</strong>Una campaña cuesta 6 unidades adicionales. Las unidades son una simplificación didáctica.</div></div><h3>Cómo preparar tu estudio</h3><ol><li>Consulta comparables y tendencias por país. Distingue los datos observados de tus hipótesis.</li><li>Construye una propuesta en cada mercado y comprueba su presupuesto. Puedes incorporar, promocionar, doblar, aplazar o descartar títulos.</li><li>Justifica dos apuestas y dos decisiones de no invertir. Incluye una oportunidad fuera del mercado de origen y explica cómo la validarías.</li><li>Descarga tu matriz y una recomendación ejecutiva con las fuentes que has consultado.</li></ol><h3>Fuentes para investigar</h3><div class="official-links">'+UI.external('Explorar rankings de Netflix','https://www.netflix.com/tudum/top10','')+UI.external('Entender los derechos por país','https://help.netflix.com/en/node/125345','')+'</div><p class="section-note">Que un título no aparezca en un ranking no demuestra que no exista demanda. La investigación puede llevarte a cuestionar las señales del caso.</p><div class="dialog-actions"><button class="btn primary" data-case-go="matrix">Construir mi catálogo <span aria-hidden="true">→</span></button><a class="btn outline" href="'+e(window.BEWAY_NETFLIX_ASSETS['assets/caso-catalogo-netflix.csv'])+'" download>Descargar los datos ↓</a></div></div>';
  }
  function recommendation(){
    return '<form class="project-form" id="case-recommendation"><div class="field"><label for="case-answer-strategy">Tu estrategia y tus prioridades</label><small>Explica tus apuestas, dónde no invertirías y cómo has repartido el presupuesto.</small><textarea id="case-answer-strategy" name="strategy" maxlength="6000" rows="5">'+e(state.answers.strategy)+'</textarea></div><div class="field"><label for="case-answer-evidence">Tu investigación y tus fuentes</label><small>Incluye enlaces y separa los datos que has encontrado de las hipótesis que propones.</small><textarea id="case-answer-evidence" name="evidence" maxlength="6000" rows="5">'+e(state.answers.evidence)+'</textarea></div><div class="field"><label for="case-answer-risks">Qué necesitas comprobar antes de decidir</label><small>Valora los riesgos, una oportunidad poco evidente y cómo validarías el interés del público.</small><textarea id="case-answer-risks" name="risks" maxlength="6000" rows="5">'+e(state.answers.risks)+'</textarea></div><p class="project-storage-note">Tu propuesta se guarda en este navegador. La descarga conserva una copia; esta demo no recibe entregas ni emite evaluaciones.</p></form>';
  }
  function allBudgets(){
    return data.countries.map(c=>{
      const s=engine.summary(c,state,data);
      return '<div'+(s.over?' class="is-over"':'')+'><strong>'+e(c.name)+'</strong><span>'+s.spent+' / '+s.budget+' unidades'+(s.over?' · Excede el presupuesto':'')+'</span><span>'+s.selected+' títulos · '+s.decided+'/'+s.available+' decisiones</span></div>';
    }).join('');
  }
  function currentBudget(){
    const c=country(),s=engine.summary(c,state,data);
    return '<div class="country-heading"><div><h3>'+e(c.name)+'</h3><p>Idioma del caso: '+e(c.language)+' · '+s.decided+' de '+s.available+' decisiones</p></div><div class="country-budget'+(s.over?' is-over':'')+'"><strong>'+s.spent+' / '+s.budget+'</strong><span>'+ (s.over?'Exceso de '+Math.abs(s.remaining):s.remaining+' disponibles')+' unidades</span></div></div><div class="budget-track'+(s.over?' is-over':'')+'" role="img" aria-label="'+e('Presupuesto utilizado: '+s.spent+' de '+s.budget+' unidades')+'"><span style="width:'+Math.min(100,s.spent/s.budget*100)+'%"></span></div>';
  }
  function table(){
    const c=country(),index=data.countries.findIndex(v=>v.id===c.id);
    const rows=data.titles.map(t=>{
      const available=t.rights.includes(c.id),action=state.decisions[c.id+':'+t.id]||'pending';
      const options=data.actions.map(a=>'<option value="'+a.id+'"'+(a.id===action?' selected':'')+'>'+e(a.label)+'</option>').join('');
      return '<tr'+(!available?' class="blocked-row"':'')+'><td><strong>'+e(t.title)+'</strong><small>'+e(t.genre+' · '+t.origin+' · '+t.language)+'</small><small>'+e(t.format)+'</small><details class="title-premise"><summary>Leer la sinopsis</summary><p>'+e(t.premise)+'</p></details></td><td><span class="affinity-value">'+t.affinity[index]+'</span><small>sobre 100</small></td><td>'+Math.round(t.license*c.factor)+'<small>unidades</small></td><td>'+(available?'<select data-case-decision="'+t.id+'" aria-label="'+e('Decisión para '+t.title+' en '+c.name)+'">'+options+'</select><span class="table-cost" data-row-cost="'+t.id+'">Coste total: '+engine.cost(t,c,action,data)+' unidades</span>':'<span class="rights-label">Sin derechos en este mercado</span>')+'</td></tr>';
    }).join('');
    return '<div class="table-scroll" tabindex="0" role="region" aria-label="Tabla de decisiones de catálogo con desplazamiento horizontal"><table class="case-table"><caption class="sr-only">Títulos ficticios y decisiones para '+e(c.name)+'</caption><thead><tr><th scope="col">Título</th><th scope="col">Interés simulado</th><th scope="col">Licencia</th><th scope="col">Tu decisión</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
  }
  function renderMatrix(){
    const panel=document.querySelector('#case-panel-matrix');if(!panel)return;
    panel.innerHTML='<div class="case-country-controls" role="group" aria-label="Seleccionar un mercado">'+data.countries.map(c=>'<button class="country-button" data-country="'+c.id+'" aria-pressed="'+(c.id===state.activeCountry)+'">'+e(c.name)+'</button>').join('')+'</div><div id="case-current-budget" aria-live="polite">'+currentBudget()+'</div>'+table()+'<p class="market-status" id="case-decision-status" role="status" aria-live="polite"></p><div class="market-budget-summary" id="case-all-budgets">'+allBudgets()+'</div><div class="dialog-actions"><button class="btn primary" data-case-go="recommendation">Redactar mi recomendación <span aria-hidden="true">→</span></button></div>';
  }
  function switchTab(name,focus=false){
    if(!['brief','matrix','recommendation'].includes(name))return;
    answers();
    document.querySelectorAll('[data-case-tab]').forEach(button=>{
      const selected=button.dataset.caseTab===name;button.setAttribute('aria-selected',String(selected));button.tabIndex=selected?0:-1;if(selected&&focus)button.focus();
    });
    document.querySelectorAll('[data-case-panel]').forEach(panel=>{panel.hidden=panel.dataset.casePanel!==name;});
    if(name==='matrix')renderMatrix();
  }
  function open(){
    if(active)persist();
    active=false;
    state=engine.cleanDraft(UI.readStorage(KEY,{}),data);
    UI.show('BEWAY / MINIPROYECTO DE MERCADOS','<div class="dialog-inner" id="market-workspace"><p class="eyebrow">INVESTIGACIÓN DE MERCADOS · ESTRATEGIA DE CATÁLOGO</p><h2>Diseña el catálogo de Netflix para seis mercados.</h2><p class="dialog-lead">Investiga al público, elige los títulos y justifica dónde concentrarías la inversión.</p><div class="case-demo-note"><strong>Caso ficticio.</strong> Los doce títulos, los costes, los derechos y las señales de interés se han creado para practicar. No representan el catálogo ni los datos internos de Netflix.</div><div class="case-tabs" role="tablist" aria-label="Pasos del miniproyecto"><button id="case-tab-brief" data-case-tab="brief" role="tab" aria-controls="case-panel-brief" aria-selected="true">1. El caso y los datos</button><button id="case-tab-matrix" data-case-tab="matrix" role="tab" aria-controls="case-panel-matrix" aria-selected="false" tabindex="-1">2. Mi catálogo por país</button><button id="case-tab-recommendation" data-case-tab="recommendation" role="tab" aria-controls="case-panel-recommendation" aria-selected="false" tabindex="-1">3. Mi recomendación</button></div><div id="case-panel-brief" class="case-panel" role="tabpanel" aria-labelledby="case-tab-brief" data-case-panel="brief">'+rules()+'</div><div id="case-panel-matrix" class="case-panel" role="tabpanel" aria-labelledby="case-tab-matrix" data-case-panel="matrix" hidden></div><div id="case-panel-recommendation" class="case-panel" role="tabpanel" aria-labelledby="case-tab-recommendation" data-case-panel="recommendation" hidden>'+recommendation()+'</div><div class="case-actionbar"><button class="btn primary" data-case-save>Guardar borrador</button><button class="btn outline" data-case-export>Descargar mi propuesta ↓</button><button class="btn outline" data-case-csv>Descargar mi matriz ↓</button></div><p class="project-save-status" id="case-save-status" role="status" aria-live="polite"></p><p class="project-storage-note">El borrador se guarda en este navegador. Descarga una copia para conservarla fuera de este dispositivo.</p></div>');
    active=true;renderMatrix();
  }
  document.addEventListener('click',event=>{
    const button=event.target.closest('[data-open-market],[data-case-tab],[data-case-go],[data-country],[data-case-save],[data-case-export],[data-case-csv]');if(!button)return;
    if(button.hasAttribute('data-open-market')){open();return;}if(!active)return;
    if(button.hasAttribute('data-case-tab'))switchTab(button.dataset.caseTab);
    else if(button.hasAttribute('data-case-go'))switchTab(button.dataset.caseGo,true);
    else if(button.hasAttribute('data-country')){
      if(!data.countries.some(c=>c.id===button.dataset.country))return;
      state.activeCountry=button.dataset.country;persist();renderMatrix();
      document.querySelector('[data-country="'+state.activeCountry+'"]')?.focus({preventScroll:true});
    }else if(button.hasAttribute('data-case-save'))persist(true);
    else if(button.hasAttribute('data-case-export')){
      persist();UI.download('BEWAY-Netflix-Mi-propuesta-de-catalogo.txt',engine.exportText(state,data));
      document.querySelector('#case-save-status').textContent='Se ha preparado la descarga de tu propuesta.';
    }else if(button.hasAttribute('data-case-csv')){
      persist();UI.download('BEWAY-Netflix-Mi-matriz-de-mercados.csv',engine.exportCSV(state,data),'text/csv;charset=utf-8');
      document.querySelector('#case-save-status').textContent='Se ha preparado la descarga de tu matriz.';
    }
  });
  document.addEventListener('change',event=>{
    const select=event.target.closest('[data-case-decision]');if(!select||!active)return;
    const c=country(),t=data.titles.find(t=>t.id===select.dataset.caseDecision);
    if(!t||!t.rights.includes(c.id)||!data.actions.some(a=>a.id===select.value))return;
    state.decisions[c.id+':'+t.id]=select.value;
    document.querySelector('[data-row-cost="'+t.id+'"]').textContent='Coste total: '+engine.cost(t,c,select.value,data)+' unidades';
    document.querySelector('#case-current-budget').innerHTML=currentBudget();
    document.querySelector('#case-all-budgets').innerHTML=allBudgets();
    const saved=persist();document.querySelector('#case-decision-status').textContent=saved?'Decisión guardada en tu borrador.':'La decisión está en pantalla. Descarga tu matriz para conservarla.';
  });
  document.addEventListener('input',event=>{if(active&&event.target.closest('#case-recommendation'))persist();});
  document.addEventListener('submit',event=>{if(event.target.id==='case-recommendation')event.preventDefault();});
  document.addEventListener('keydown',event=>{
    const tab=event.target.closest('[data-case-tab]');if(!tab||!active)return;
    const tabs=[...document.querySelectorAll('[data-case-tab]')];let index=tabs.indexOf(tab);
    if(event.key==='ArrowRight')index=(index+1)%tabs.length;else if(event.key==='ArrowLeft')index=(index+tabs.length-1)%tabs.length;else if(event.key==='Home')index=0;else if(event.key==='End')index=tabs.length-1;else return;
    event.preventDefault();switchTab(tabs[index].dataset.caseTab,true);
  });
  window.addEventListener('beway:before-dialog-change',()=>{if(active){persist();active=false;}});
  window.addEventListener('pagehide',()=>persist());
})();
