/* Contenido de la propuesta y datos ficticios del caso. */
window.BEWAY_NETFLIX = {
  "courses": [
    {
      "id": "guion",
      "tag": "GUION Y DESARROLLO",
      "cover": "guion",
      "short": "Aprende a desarrollar personajes, construir una historia por episodios y dar forma al guion de un piloto.",
      "audience": "Para estudiantes interesados en escritura, Comunicación, Humanidades y creación audiovisual.",
      "outcome": "Entenderás cómo se desarrolla una propuesta de serie y cómo se revisan sus personajes, su estructura y sus escenas.",
      "resources": [
        "Ficha de premisa y universo",
        "Ficha de personaje",
        "Mapa de conflictos",
        "Mapa de temporada",
        "Sinopsis y escaleta comentadas",
        "Escena con anotaciones",
        "Guion antes y después de las notas",
        "Ejemplo de biblia breve"
      ],
      "title": "Curso para guionistas",
      "totalMinutes": 480,
      "videoMinutes": 390,
      "resourcesMinutes": 60,
      "assessmentMinutes": 30,
      "modules": [
        {
          "title": "Definir la premisa, el formato, el género y el mundo de la serie.",
          "videoMinutes": 50,
          "resource": "Ficha de premisa y universo",
          "lessons": [
            "Elegir una idea que sostenga varios episodios",
            "Formato, tono y género",
            "Definir el mundo de la serie"
          ]
        },
        {
          "title": "Construir personajes con objetivos, conflictos y relaciones.",
          "videoMinutes": 50,
          "resource": "Ficha de personaje",
          "lessons": [
            "Objetivos y obstáculos de los personajes",
            "Relaciones y contradicciones",
            "Presentación comentada de un personaje"
          ]
        },
        {
          "title": "Desarrollar el motor narrativo y la evolución de la historia.",
          "videoMinutes": 50,
          "resource": "Mapa de conflictos",
          "lessons": [
            "El conflicto que hace avanzar la historia",
            "Tramas principales y secundarias",
            "Un motor narrativo que pueda continuar"
          ]
        },
        {
          "title": "Organizar los arcos de temporada y de episodio.",
          "videoMinutes": 45,
          "resource": "Mapa de temporada",
          "lessons": [
            "Evolución de la temporada",
            "Arcos de personaje y episodios",
            "Preparar un mapa de tramas"
          ]
        },
        {
          "title": "Estructurar el piloto mediante una sinopsis y una escaleta.",
          "videoMinutes": 50,
          "resource": "Sinopsis y escaleta comentadas",
          "lessons": [
            "La promesa del primer episodio",
            "De la sinopsis a la escaleta",
            "Escenas que abren nuevas preguntas"
          ]
        },
        {
          "title": "Escribir escenas, diálogos y subtexto.",
          "videoMinutes": 50,
          "resource": "Escena con anotaciones",
          "lessons": [
            "Acción, punto de vista y subtexto",
            "Diálogos que expresan un conflicto",
            "Lectura comentada de una escena"
          ]
        },
        {
          "title": "Revisar el guion a partir de notas y lecturas comentadas.",
          "videoMinutes": 50,
          "resource": "Guion antes y después de las notas",
          "lessons": [
            "Cómo interpretar las notas",
            "Reescritura y coherencia de la historia",
            "Comparar una escena antes y después"
          ]
        },
        {
          "title": "Preparar una biblia breve y presentar la propuesta de serie.",
          "videoMinutes": 45,
          "resource": "Ejemplo de biblia breve",
          "lessons": [
            "Los elementos de una biblia breve",
            "Explicar el proyecto en una presentación",
            "Ejemplo comentado y evaluación de cierre"
          ]
        }
      ]
    },
    {
      "id": "presupuestos",
      "tag": "PRODUCCIÓN Y GESTIÓN",
      "cover": "presupuestos",
      "short": "Descubre cómo un guion se traduce en jornadas, equipos y partidas, y cómo se controla el presupuesto de una serie.",
      "audience": "Para estudiantes de ADE, Economía, Finanzas, Ingeniería, Comunicación y producción audiovisual.",
      "outcome": "Podrás interpretar un presupuesto simplificado, entender sus supuestos y explicar el efecto económico de las decisiones de producción.",
      "resources": [
        "Estructura de un presupuesto",
        "Ejemplo de desglose",
        "Plan de rodaje simplificado",
        "Supuestos de desarrollo y reparto",
        "Partidas explicadas",
        "Calendario de posproducción",
        "Plantilla de presupuesto opcional",
        "Ejemplo de control de costes"
      ],
      "title": "Curso de presupuestos para producciones audiovisuales",
      "totalMinutes": 480,
      "videoMinutes": 390,
      "resourcesMinutes": 60,
      "assessmentMinutes": 30,
      "modules": [
        {
          "title": "Entender el proceso de producción y los presupuestos por temporada y episodio.",
          "videoMinutes": 50,
          "resource": "Estructura de un presupuesto",
          "lessons": [
            "Las fases de una producción",
            "Temporada, episodios y costes compartidos",
            "Cómo leer la estructura de un presupuesto"
          ]
        },
        {
          "title": "Desglosar el guion en reparto, localizaciones, recursos y necesidades.",
          "videoMinutes": 50,
          "resource": "Ejemplo de desglose",
          "lessons": [
            "Del guion a las necesidades de producción",
            "Reparto, espacios, recursos y efectos",
            "Desglose comentado de una secuencia"
          ]
        },
        {
          "title": "Relacionar el plan de rodaje y las jornadas con el coste.",
          "videoMinutes": 50,
          "resource": "Plan de rodaje simplificado",
          "lessons": [
            "Agrupar escenas y localizaciones",
            "Calendario, equipos y jornadas",
            "El coste de cambiar una decisión de rodaje"
          ]
        },
        {
          "title": "Presupuestar desarrollo, guion, derechos y reparto.",
          "videoMinutes": 45,
          "resource": "Supuestos de desarrollo y reparto",
          "lessons": [
            "Desarrollo, guion y derechos",
            "Reparto y necesidades de contratación",
            "Cómo documentar los supuestos"
          ]
        },
        {
          "title": "Estimar equipo técnico, localizaciones, arte, transporte y otros costes del rodaje.",
          "videoMinutes": 50,
          "resource": "Partidas explicadas",
          "lessons": [
            "Equipos técnicos y alquiler de material",
            "Arte, vestuario, transportes y localizaciones",
            "Construcción comentada de las partidas"
          ]
        },
        {
          "title": "Incorporar montaje, sonido, música, efectos y entregas.",
          "videoMinutes": 50,
          "resource": "Calendario de posproducción",
          "lessons": [
            "Montaje, sonido, música y efectos",
            "Versiones lingüísticas y entregas",
            "Preparar el calendario de posproducción"
          ]
        },
        {
          "title": "Consolidar partidas, costes compartidos y contingencias.",
          "videoMinutes": 50,
          "resource": "Plantilla de presupuesto opcional",
          "lessons": [
            "Cantidades, tarifas y partidas",
            "Contingencias y escenarios",
            "Consolidar un presupuesto simplificado"
          ]
        },
        {
          "title": "Comparar presupuesto y gasto, evaluar cambios y justificar ajustes.",
          "videoMinutes": 45,
          "resource": "Ejemplo de control de costes",
          "lessons": [
            "Comprometido, pagado y pendiente",
            "Comparar lo previsto con el gasto",
            "Proponer ajustes y evaluación de cierre"
          ]
        }
      ]
    },
    {
      "id": "marketing",
      "tag": "MARKETING Y AUDIENCIAS",
      "cover": "marketing",
      "short": "Conoce cómo se define el público, se construye una campaña y se organiza el estreno de una serie o película.",
      "audience": "Para estudiantes de Marketing, Publicidad, Comunicación, ADE y estudios audiovisuales.",
      "outcome": "Entenderás cómo relacionar público, mensaje, canales, inversión y resultados en una campaña de lanzamiento.",
      "resources": [
        "Ficha de público y comparables",
        "Ejemplo de posicionamiento",
        "Análisis de piezas promocionales",
        "Calendario de campaña",
        "Plan de contenidos",
        "Ficha de activación",
        "Ejemplo de plan de medios",
        "Cuadro de indicadores explicado"
      ],
      "title": "Curso de marketing para el mundo audiovisual",
      "totalMinutes": 480,
      "videoMinutes": 390,
      "resourcesMinutes": 60,
      "assessmentMinutes": 30,
      "modules": [
        {
          "title": "Investigar públicos, mercados y títulos comparables.",
          "videoMinutes": 50,
          "resource": "Ficha de público y comparables",
          "lessons": [
            "Públicos, mercados y comparables",
            "Cómo interpretar una señal de interés",
            "Plantear hipótesis que se puedan contrastar"
          ]
        },
        {
          "title": "Definir el posicionamiento y el mensaje de campaña.",
          "videoMinutes": 50,
          "resource": "Ejemplo de posicionamiento",
          "lessons": [
            "Qué promete la historia al espectador",
            "Un mismo título ante públicos distintos",
            "Escribir un mensaje de campaña"
          ]
        },
        {
          "title": "Analizar carteles, avances y tráileres y su adaptación por público.",
          "videoMinutes": 50,
          "resource": "Análisis de piezas promocionales",
          "lessons": [
            "El papel del cartel, el avance y el tráiler",
            "Qué revelar y qué reservar",
            "Adaptación de materiales por público"
          ]
        },
        {
          "title": "Planificar el calendario anterior y posterior al estreno.",
          "videoMinutes": 45,
          "resource": "Calendario de campaña",
          "lessons": [
            "Antes, durante y después del estreno",
            "Hitos, piezas y coordinación",
            "Construir un calendario de lanzamiento"
          ]
        },
        {
          "title": "Trabajar redes sociales, creadores y comunidades de fans.",
          "videoMinutes": 50,
          "resource": "Plan de contenidos",
          "lessons": [
            "Elegir los canales y los formatos",
            "Creadores y comunidades de fans",
            "Mantener la conversación sobre una historia"
          ]
        },
        {
          "title": "Combinar prensa, alianzas y experiencias de lanzamiento.",
          "videoMinutes": 50,
          "resource": "Ficha de activación",
          "lessons": [
            "Prensa y comunicación del estreno",
            "Alianzas y experiencias para los fans",
            "Diseñar una activación universitaria"
          ]
        },
        {
          "title": "Distribuir el presupuesto promocional entre canales.",
          "videoMinutes": 50,
          "resource": "Ejemplo de plan de medios",
          "lessons": [
            "Objetivos y distribución del presupuesto",
            "Medios pagados, propios y cobertura obtenida",
            "Comparar dos planes de inversión"
          ]
        },
        {
          "title": "Interpretar resultados y decidir qué mejorar.",
          "videoMinutes": 45,
          "resource": "Cuadro de indicadores explicado",
          "lessons": [
            "Alcance, interacción e interés por ver",
            "Resultados, atribución e hipótesis",
            "Revisión comentada y evaluación de cierre"
          ]
        }
      ]
    }
  ],
  "case": {
    "version": 1,
    "countries": [
      {
        "id": "es",
        "name": "España",
        "language": "Español",
        "budget": 100,
        "factor": 1
      },
      {
        "id": "mx",
        "name": "México",
        "language": "Español",
        "budget": 100,
        "factor": 0.9
      },
      {
        "id": "br",
        "name": "Brasil",
        "language": "Portugués",
        "budget": 100,
        "factor": 0.95
      },
      {
        "id": "us",
        "name": "Estados Unidos",
        "language": "Inglés",
        "budget": 100,
        "factor": 1.3
      },
      {
        "id": "de",
        "name": "Alemania",
        "language": "Alemán",
        "budget": 100,
        "factor": 1.1
      },
      {
        "id": "in",
        "name": "India",
        "language": "Hindi",
        "budget": 100,
        "factor": 0.85
      }
    ],
    "titles": [
      {
        "id": "turno",
        "title": "Turno de noche",
        "genre": "Thriller",
        "origin": "España",
        "language": "Español",
        "format": "6 × 45 min",
        "license": 13,
        "affinity": [
          86,
          80,
          67,
          62,
          78,
          60
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "de",
          "in"
        ],
        "premise": "Una médica investiga una desaparición durante las noches de un hospital."
      },
      {
        "id": "kilometro",
        "title": "Kilómetro cero",
        "genre": "Comedia",
        "origin": "México",
        "language": "Español",
        "format": "8 × 25 min",
        "license": 10,
        "affinity": [
          72,
          90,
          73,
          70,
          61,
          64
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "us",
          "de",
          "in"
        ],
        "premise": "Dos hermanos heredan una estación de autobuses y deben mantenerla abierta."
      },
      {
        "id": "cartas",
        "title": "Cartas de invierno",
        "genre": "Drama",
        "origin": "Corea del Sur",
        "language": "Coreano",
        "format": "8 × 45 min",
        "license": 14,
        "affinity": [
          77,
          85,
          87,
          81,
          76,
          80
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "us",
          "de",
          "in"
        ],
        "premise": "Un archivo de cartas vuelve a unir a una familia que vive en tres países."
      },
      {
        "id": "pista",
        "title": "Fuera de pista",
        "genre": "Documental deportivo",
        "origin": "Estados Unidos",
        "language": "Inglés",
        "format": "4 × 50 min",
        "license": 9,
        "affinity": [
          75,
          68,
          80,
          89,
          78,
          83
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "us",
          "in"
        ],
        "premise": "Deportistas de distintas disciplinas se preparan para volver a competir."
      },
      {
        "id": "cristal",
        "title": "Ciudad de cristal",
        "genre": "Ciencia ficción",
        "origin": "Alemania",
        "language": "Alemán",
        "format": "6 × 50 min",
        "license": 15,
        "affinity": [
          78,
          71,
          75,
          84,
          92,
          80
        ],
        "rights": [
          "es",
          "br",
          "us",
          "de",
          "in"
        ],
        "premise": "Una ingeniera descubre que los recuerdos de una ciudad están siendo alterados."
      },
      {
        "id": "orbita",
        "title": "La última órbita",
        "genre": "Animación",
        "origin": "Japón",
        "language": "Japonés",
        "format": "8 × 24 min",
        "license": 12,
        "affinity": [
          80,
          85,
          91,
          87,
          82,
          75
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "us",
          "de",
          "in"
        ],
        "premise": "Una joven tripulación intenta recuperar una señal perdida en el espacio."
      },
      {
        "id": "casa",
        "title": "Casa compartida",
        "genre": "Reality",
        "origin": "Brasil",
        "language": "Portugués",
        "format": "8 × 40 min",
        "license": 8,
        "affinity": [
          66,
          74,
          91,
          65,
          60,
          63
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "us",
          "de"
        ],
        "premise": "Seis participantes convierten una casa vacía en un proyecto comunitario."
      },
      {
        "id": "marea",
        "title": "Marea alta",
        "genre": "Documental de naturaleza",
        "origin": "España",
        "language": "Español",
        "format": "4 × 40 min",
        "license": 7,
        "affinity": [
          83,
          79,
          84,
          80,
          88,
          85
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "us",
          "de",
          "in"
        ],
        "premise": "Historias de comunidades costeras y su relación con la vida marina."
      },
      {
        "id": "mumbai",
        "title": "Un verano en Mumbai",
        "genre": "Romance",
        "origin": "India",
        "language": "Hindi",
        "format": "6 × 35 min",
        "license": 11,
        "affinity": [
          73,
          78,
          74,
          76,
          70,
          93
        ],
        "rights": [
          "es",
          "mx",
          "us",
          "de",
          "in"
        ],
        "premise": "Dos desconocidos coinciden cada día mientras preparan una celebración."
      },
      {
        "id": "secretos",
        "title": "Mercado de secretos",
        "genre": "Thriller",
        "origin": "Turquía",
        "language": "Turco",
        "format": "8 × 45 min",
        "license": 12,
        "affinity": [
          85,
          81,
          77,
          68,
          83,
          72
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "us",
          "de",
          "in"
        ],
        "premise": "Una comerciante descubre una trama que conecta varios negocios del barrio."
      },
      {
        "id": "notas",
        "title": "Entre dos notas",
        "genre": "Drama musical",
        "origin": "Brasil",
        "language": "Portugués",
        "format": "Película · 110 min",
        "license": 9,
        "affinity": [
          76,
          84,
          92,
          82,
          71,
          79
        ],
        "rights": [
          "mx",
          "br",
          "us",
          "de",
          "in"
        ],
        "premise": "Dos músicos con trayectorias opuestas comparten una última gira."
      },
      {
        "id": "sabado",
        "title": "El club del sábado",
        "genre": "Comedia",
        "origin": "Estados Unidos",
        "language": "Inglés",
        "format": "6 × 25 min",
        "license": 8,
        "affinity": [
          77,
          83,
          72,
          88,
          79,
          70
        ],
        "rights": [
          "es",
          "mx",
          "br",
          "us",
          "de",
          "in"
        ],
        "premise": "Un grupo de vecinos crea un club para cumplir pequeños proyectos pendientes."
      }
    ],
    "subtitleCost": 2,
    "dubbingCost": 8,
    "promotionCost": 6,
    "actions": [
      {
        "id": "pending",
        "label": "Por decidir"
      },
      {
        "id": "include",
        "label": "Incorporar"
      },
      {
        "id": "promote",
        "label": "Incorporar y promocionar"
      },
      {
        "id": "localise",
        "label": "Doblar y promocionar"
      },
      {
        "id": "defer",
        "label": "Aplazar"
      },
      {
        "id": "exclude",
        "label": "Descartar en este caso"
      }
    ]
  },
  "sources": [
    {
      "group": "Netflix",
      "title": "Visión y actividad de la compañía",
      "url": "https://about.netflix.com/es_es"
    },
    {
      "group": "Netflix",
      "title": "Alcance internacional",
      "url": "https://help.netflix.com/es-es/node/14164"
    },
    {
      "group": "Netflix",
      "title": "Equipos de marketing y experiencias",
      "url": "https://jobs.netflix.com/careers/marketing"
    },
    {
      "group": "Netflix",
      "title": "Cultura y principios de trabajo",
      "url": "https://jobs.netflix.com/culture"
    },
    {
      "group": "Netflix",
      "title": "Por qué el catálogo cambia según el país",
      "url": "https://help.netflix.com/en/node/125345"
    },
    {
      "group": "Netflix",
      "title": "Rankings de títulos por mercado",
      "url": "https://www.netflix.com/tudum/top10"
    },
    {
      "group": "Netflix",
      "title": "Tienda oficial",
      "url": "https://www.netflix.shop/"
    },
    {
      "group": "Guion",
      "title": "USC · Writing for Screen & Television",
      "url": "https://cinema.usc.edu/writing/index.cfm"
    },
    {
      "group": "Guion",
      "title": "UNIR · Máster Universitario en Creación de Guiones Audiovisuales",
      "url": "https://www.unir.net/artes/master-guiones-audiovisuales/plan-de-estudios/"
    },
    {
      "group": "Guion",
      "title": "BBC Maestro · Jed Mercurio, Writing Drama for Television",
      "url": "https://www.bbcmaestro.com/courses/jed-mercurio/writing-drama-for-television"
    },
    {
      "group": "Guion",
      "title": "MasterClass · Shonda Rhimes, Writing for Television",
      "url": "https://www.masterclass.com/classes/shonda-rhimes-teaches-writing-for-television"
    },
    {
      "group": "Producción",
      "title": "UC3M · Máster Universitario en Cine y Televisión",
      "url": "https://www.uc3m.es/master/cine-television"
    },
    {
      "group": "Producción",
      "title": "UNIR · Máster Universitario en Producción Ejecutiva en la Industria Audiovisual",
      "url": "https://www.unir.net/artes/master-produccion-audiovisual/"
    },
    {
      "group": "Producción",
      "title": "Entertainment Partners · Movie Magic Budgeting Basics",
      "url": "https://www.ep.com/ep-store/movie-magic-budgeting-basics-course/"
    },
    {
      "group": "Producción",
      "title": "UCLA Extension · Movie Magic Budgeting",
      "url": "https://pages.uclaextension.edu/entertainment/film-tv/course/movie-magic-budgeting-film-tv-x-479088"
    },
    {
      "group": "Marketing",
      "title": "UCLA Extension · Marketing Entertainment",
      "url": "https://pages.uclaextension.edu/entertainment/film-tv/course/marketing-entertainment-strategies-global-marketplace-mgmt-x-47699"
    },
    {
      "group": "Marketing",
      "title": "NFTS · Marketing, Distribution, Sales and Exhibition",
      "url": "https://nfts.co.uk/marketing-distribution-sales-and-exhibition"
    },
    {
      "group": "Marketing",
      "title": "Stage 32 · Advanced Digital Marketing for Your Indie Film",
      "url": "https://www.stage32.com/education/products/advanced-digital-marketing-for-your-indie-film-or-production-company"
    },
    {
      "group": "Comunidad",
      "title": "CLH · Comunidad de Líderes Hispanoamericanos",
      "url": "https://clhglobal.org/"
    }
  ],
  "challenges": [
    {
      "id": "elegir",
      "number": "01",
      "area": "PRODUCTO · EXPERIENCIA DE USUARIO",
      "title": "Elegir qué ver en menos de dos minutos",
      "short": "Transforma el “¿qué vemos?” en una experiencia más fácil, rápida y personal.",
      "image": "paula",
      "mission": "Diseña una función de Netflix que ayude a elegir una película o una serie en menos de dos minutos.",
      "tasks": [
        "Elige una situación concreta: poco tiempo, un estado de ánimo o ponerse de acuerdo con otra persona.",
        "Explica dónde aparece tu función, qué hace el usuario y cómo llega a una elección.",
        "Dibuja entre 3 y 5 pasos o pantallas. Pueden ser bocetos sencillos."
      ],
      "slides": [
        "La situación y el problema",
        "Tu propuesta",
        "El recorrido visual",
        "Por qué ayuda a elegir"
      ],
      "criteria": "Claridad del problema, utilidad de la solución, sencillez de uso y coherencia del recorrido.",
      "extra": "No necesitas programar ni crear un prototipo funcional. Los dos minutos son el objetivo de tu diseño; no tienes que realizar una prueba cronometrada."
    },
    {
      "id": "ads",
      "number": "02",
      "area": "NETFLIX ADS · MARCAS Y AUDIENCIAS",
      "title": "Publicidad que sí me interesa",
      "short": "Imagina una conexión entre historias y marcas que aporte algo al espectador.",
      "image": "alex",
      "mission": "Propón una experiencia publicitaria relacionada con un contenido que resulte útil o interesante y respete la experiencia de visionado.",
      "tasks": [
        "Escoge una escena real o inventada y un producto o servicio que tenga sentido en ella.",
        "Define cuándo aparece la propuesta y cómo puede interactuar quien esté interesado.",
        "Muestra en 3–5 bocetos tanto el camino de quien participa como el de quien prefiere seguir viendo.",
        "Explica qué gana el espectador y qué oportunidad abre para la marca."
      ],
      "slides": [
        "Escena y contexto",
        "La idea publicitaria",
        "Cómo funciona",
        "Valor para el espectador y la marca"
      ],
      "criteria": "Creatividad, conexión con el contenido, utilidad y claridad de la experiencia.",
      "extra": "Es una propuesta conceptual. No necesitas programar, montar una tienda ni cerrar acuerdos con marcas."
    },
    {
      "id": "estreno",
      "number": "03",
      "area": "MARKETING · COMUNIDAD",
      "title": "Convertir un estreno en un plan universitario",
      "short": "Haz que una historia despierte conversaciones, curiosidad y ganas de vivirla.",
      "image": "elena",
      "mission": "Diseña una experiencia que conecte un estreno de Netflix con estudiantes universitarios y les dé ganas de descubrirlo.",
      "tasks": [
        "Elige una serie o película real o ficticia y define a qué estudiantes te diriges.",
        "Diseña una experiencia física, digital o híbrida vinculada a su universo.",
        "Cuenta el recorrido: cómo la descubren, cómo participan y qué se llevan.",
        "Indica cuándo sucedería, los recursos necesarios y cómo evaluarías su resultado."
      ],
      "slides": [
        "Título, público e idea",
        "La experiencia y su recorrido",
        "Ejemplos visuales",
        "Difusión y calendario",
        "Por qué funciona y cómo medirla"
      ],
      "criteria": "Creatividad, conexión con el título, atractivo para estudiantes, claridad y viabilidad.",
      "extra": "Solo tienes que diseñar la propuesta. No hace falta organizar el evento, reservar espacios ni reunir participantes."
    }
  ],
  "people": [
    {
      "id": "martina-leich",
      "name": "Martina Leicht",
      "university": "Universidad de Montevideo",
      "country": "Uruguay",
      "area": "Comunicación estratégica/Marketing",
      "image": "assets/ambassadors/martina-leich.webp",
      "linkedIn": "https://www.linkedin.com/in/martina-leicht-05b44b340/"
    },
    {
      "id": "emily-torres-pineda",
      "name": "Emily Torres Pineda",
      "university": "Universidad del Rosario",
      "country": "Colombia",
      "area": "Derecho",
      "image": "assets/ambassadors/emily-torres-pineda.webp",
      "linkedIn": "https://www.linkedin.com/in/emily-torres-pineda/"
    },
    {
      "id": "michelle-rogel",
      "name": "Michelle Rogel",
      "university": "Universidad Anáhuac Mayab",
      "country": "México",
      "area": "Ingeniería Mecatrónica",
      "image": "assets/ambassadors/michelle-rogel.webp",
      "linkedIn": "https://www.linkedin.com/in/michelle-rogel-garc%C3%ADa-a37820219/"
    },
    {
      "id": "andrea-venegas",
      "name": "Andrea Venegas",
      "university": "Universidad de Granada",
      "country": "España",
      "area": "Criminología y Seguridad",
      "image": "assets/ambassadors/andrea-venegas.jpg",
      "linkedIn": "https://www.linkedin.com/in/andrea-venegas-de-la-rosa-a34162365"
    },
    {
      "id": "camila-calvo",
      "name": "Camila Calvo",
      "university": "ADEN",
      "country": "Panamá",
      "area": "Marketing",
      "image": "assets/ambassadors/camila-calvo.png",
      "linkedIn": "https://www.linkedin.com/in/camila-calvo-de-la-guardia/"
    }
  ]
};
